<?php
// YTX Tools Hub configuration

define('DB_HOST', 'localhost');
define('DB_USER', 'ytx_app');
define('DB_PASS', 'ytx_local_2026');
define('DB_NAME', 'ytx_tools');

define('ADMIN_USERNAME', 'admin');
define('ADMIN_PASSWORD', 'admin123');
define('ADMIN_SESSION_KEY', 'ytx_admin_logged_in');

function getDB() {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        if ($conn->connect_error) {
            die(json_encode(['error' => 'Database connection failed: ' . $conn->connect_error]));
        }
        $conn->set_charset('utf8mb4');
    }
    return $conn;
}

function getSetting($key, $default = '') {
    $db = getDB();
    $key = $db->real_escape_string($key);
    $result = $db->query("SELECT value FROM settings WHERE `key` = '$key' LIMIT 1");
    if ($result && $row = $result->fetch_assoc()) return $row['value'];
    return $default;
}

function setSetting($key, $value) {
    $db = getDB();
    $key = $db->real_escape_string($key);
    $value = $db->real_escape_string($value);
    $db->query("INSERT INTO settings (`key`, value) VALUES ('$key', '$value') ON DUPLICATE KEY UPDATE value = '$value'");
}

/** Store a validated image inside assets/img and return its web path. */
function saveUploadedImage($field, $prefix, &$error, $directory = null) {
    if (empty($_FILES[$field]['tmp_name'])) return '';
    if ($_FILES[$field]['error'] !== UPLOAD_ERR_OK) {
        $error = 'The image upload could not be completed.';
        return '';
    }
    if ($_FILES[$field]['size'] > 5 * 1024 * 1024) {
        $error = 'Images must be 5 MB or smaller.';
        return '';
    }
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $_FILES[$field]['tmp_name']);
    finfo_close($finfo);
    $allowed = ['image/png'=>'png', 'image/jpeg'=>'jpg', 'image/webp'=>'webp', 'image/gif'=>'gif', 'image/svg+xml'=>'svg', 'image/x-icon'=>'ico', 'image/vnd.microsoft.icon'=>'ico'];
    if (!isset($allowed[$mime])) {
        $error = 'Only PNG, JPG, WEBP, GIF, SVG or ICO image files are allowed.';
        return '';
    }
    $targetDir = $directory ?: dirname(__DIR__) . '/assets/img/uploads';
    if (!is_dir($targetDir) && !mkdir($targetDir, 0755, true)) {
        $error = 'The image upload folder is not writable.';
        return '';
    }
    $filename = preg_replace('/[^a-z0-9-]/i', '-', strtolower($prefix)) . '-' . date('YmdHis') . '-' . bin2hex(random_bytes(3)) . '.' . $allowed[$mime];
    $target = rtrim($targetDir, '/') . '/' . $filename;
    if (!move_uploaded_file($_FILES[$field]['tmp_name'], $target)) {
        $error = 'Could not save the uploaded image.';
        return '';
    }
    $relativeBase = dirname(__DIR__) . '/';
    return str_replace(DIRECTORY_SEPARATOR, '/', str_replace($relativeBase, '', $target));
}

session_start();
