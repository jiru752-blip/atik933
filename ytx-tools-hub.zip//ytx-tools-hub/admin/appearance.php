<?php
// Developed by https://t.me/Infinity_Codex | owner: t.me/zerox6t9

require_once '../includes/config.php';
if (!isset($_SESSION[ADMIN_SESSION_KEY]) || !$_SESSION[ADMIN_SESSION_KEY]) {
    header('Location: login.php'); exit;
}

$db = getDB();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $primary_color      = trim($_POST['primary_color'] ?? '#007AFF');
    $particles_enabled  = isset($_POST['particles_enabled']) ? '1' : '0';
    $glow_enabled       = isset($_POST['glow_enabled']) ? '1' : '0';
    $animations_enabled = isset($_POST['animations_enabled']) ? '1' : '0';
    setSetting('primary_color', $primary_color);
    setSetting('particles_enabled', $particles_enabled);
    setSetting('glow_enabled', $glow_enabled);
    setSetting('animations_enabled', $animations_enabled);
    $msg = '✅ Appearance saved!';
}

$primary_color      = getSetting('primary_color', '#007AFF');
$particles_enabled  = getSetting('particles_enabled', '1');
$glow_enabled       = getSetting('glow_enabled', '1');
$animations_enabled = getSetting('animations_enabled', '1');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appearance - Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>:root { --primary: <?= htmlspecialchars($primary_color) ?>; }</style>
</head>
<body>
<?php include 'partials/sidebar.php'; ?>
<div class="admin-content">
    <?php include 'partials/topbar.php'; ?>
    <div class="admin-body">
        <div class="page-header">
            <h1><i class="fas fa-paint-brush"></i> Appearance</h1>
            <p>Customize colors and effects</p>
        </div>

        <?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

        <form method="POST">
        <div class="card">
            <div class="card-header"><i class="fas fa-palette"></i> Color Theme</div>
            <div class="card-body">
                <div class="form-group">
                    <label>Primary Color</label>
                    <div style="display:flex; align-items:center; gap:14px;">
                        <input type="color" name="primary_color" value="<?= htmlspecialchars($primary_color) ?>"
                               style="width:56px; height:44px; border:none; border-radius:10px; cursor:pointer; padding:2px;"
                               id="color-picker">
                        <input type="text" id="color-hex" class="form-control" style="width:140px;"
                               value="<?= htmlspecialchars($primary_color) ?>"
                               oninput="syncColor(this.value)">
                        <span style="font-size:13px; color:#888;">Current accent color for buttons, icons, glow effects</span>
                    </div>
                    <div style="margin-top:14px; display:flex; gap:10px; flex-wrap:wrap;">
                    <?php
                    $presets = ['#007AFF','#5856D6','#FF2D55','#FF9500','#34C759','#00C7BE','#FF375F','#AF52DE','#FF6B00','#1DB954'];
                    foreach ($presets as $c):
                    ?>
                    <span class="color-preset" style="background:<?= $c ?>; width:36px; height:36px; border-radius:50%; cursor:pointer; display:inline-block; border:2px solid rgba(0,0,0,0.1); transition:0.2s;"
                          onclick="setPreset('<?= $c ?>')" title="<?= $c ?>"></span>
                    <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><i class="fas fa-magic"></i> Effects & Animations</div>
            <div class="card-body">
                <div style="display:flex; flex-direction:column; gap:14px;">
                    <label class="toggle-label">
                        <div class="toggle-info">
                            <strong>Particle Background</strong>
                            <small>Floating dots animation in the background</small>
                        </div>
                        <div class="toggle-switch">
                            <input type="checkbox" name="particles_enabled" <?= $particles_enabled === '1' ? 'checked' : '' ?>>
                            <span class="toggle-slider"></span>
                        </div>
                    </label>
                    <label class="toggle-label">
                        <div class="toggle-info">
                            <strong>Glow Effects</strong>
                            <small>Blue glow on tool icons and cards on hover</small>
                        </div>
                        <div class="toggle-switch">
                            <input type="checkbox" name="glow_enabled" <?= $glow_enabled === '1' ? 'checked' : '' ?>>
                            <span class="toggle-slider"></span>
                        </div>
                    </label>
                    <label class="toggle-label">
                        <div class="toggle-info">
                            <strong>Card Animations</strong>
                            <small>Entrance animations and hover transitions on tool cards</small>
                        </div>
                        <div class="toggle-switch">
                            <input type="checkbox" name="animations_enabled" <?= $animations_enabled === '1' ? 'checked' : '' ?>>
                            <span class="toggle-slider"></span>
                        </div>
                    </label>
                </div>
            </div>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-primary btn-lg">
                <i class="fas fa-save"></i> Save Appearance
            </button>
        </div>
        </form>

    </div>
</div>
<script src="../assets/js/admin.js"></script>
<script>
document.getElementById('color-picker').addEventListener('input', function() {
    document.getElementById('color-hex').value = this.value;
    document.querySelector('[name="primary_color"]').value = this.value;
    document.documentElement.style.setProperty('--primary', this.value);
});
function syncColor(val) {
    if (/^#[0-9A-Fa-f]{6}$/.test(val)) {
        document.getElementById('color-picker').value = val;
        document.documentElement.style.setProperty('--primary', val);
    }
}
function setPreset(color) {
    document.getElementById('color-picker').value = color;
    document.getElementById('color-hex').value = color;
    document.documentElement.style.setProperty('--primary', color);
}
</script>
</body>
</html>
