<?php
// Developed by https://t.me/Infinity_Codex | owner: t.me/zerox6t9

require_once '../includes/config.php';
if (!isset($_SESSION[ADMIN_SESSION_KEY]) || !$_SESSION[ADMIN_SESSION_KEY]) {
    header('Location: login.php'); exit;
}

$db = getDB();
$primary_color = getSetting('primary_color', '#007AFF');
$msg = $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $message = trim($_POST['message'] ?? '');
        $type = $_POST['type'] ?? 'info';
        $active = isset($_POST['is_active']) ? 1 : 0;
        if (!$message) { $err = 'Message is required.'; }
        else {
            $m = $db->real_escape_string($message);
            $t = $db->real_escape_string($type);
            $db->query("INSERT INTO announcements (message, type, is_active) VALUES ('$m', '$t', $active)");
            $msg = '✅ Announcement added!';
        }
    }
    if ($action === 'delete') {
        $id = intval($_POST['id']);
        $db->query("DELETE FROM announcements WHERE id=$id");
        $msg = '🗑️ Announcement deleted.';
    }
    if ($action === 'toggle') {
        $id = intval($_POST['id']);
        $db->query("UPDATE announcements SET is_active = IF(is_active=1, 0, 1) WHERE id=$id");
        $msg = '✅ Status updated.';
    }
}

$ann_res = $db->query("SELECT * FROM announcements ORDER BY id DESC");
$anns = [];
if ($ann_res) while ($row = $ann_res->fetch_assoc()) $anns[] = $row;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcements - Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>:root { --primary: <?= htmlspecialchars($primary_color) ?>; }</style>
</head>
<body>
<?php include 'partials/sidebar.php'; ?>
<div class="admin-content">
    <?php include 'partials/topbar.php'; ?>
    <div class="admin-body">
        <div class="page-header">
            <h1><i class="fas fa-bullhorn"></i> Announcements</h1>
        </div>

        <?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
        <?php if ($err): ?><div class="alert alert-danger"><?= htmlspecialchars($err) ?></div><?php endif; ?>

        <div class="card">
            <div class="card-header"><i class="fas fa-plus-circle"></i> Add Announcement</div>
            <div class="card-body">
                <form method="POST">
                    <input type="hidden" name="action" value="add">
                    <div class="form-group">
                        <label>Message</label>
                        <textarea name="message" class="form-control" rows="2"
                                  placeholder="Announcement message..." required></textarea>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Type</label>
                            <select name="type" class="form-control">
                                <option value="info">ℹ️ Info (Blue)</option>
                                <option value="success">✅ Success (Green)</option>
                                <option value="warning">⚠️ Warning (Orange)</option>
                                <option value="error">❌ Error (Red)</option>
                            </select>
                        </div>
                        <div class="form-group" style="padding-top: 28px;">
                            <label class="checkbox-label">
                                <input type="checkbox" name="is_active" checked>
                                Active (show on site)
                            </label>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Add</button>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><i class="fas fa-list"></i> All Announcements</div>
            <div class="card-body" style="padding: 0;">
                <?php if (empty($anns)): ?>
                <div style="padding:24px; text-align:center; color:#999;">No announcements yet.</div>
                <?php else: ?>
                <?php foreach ($anns as $ann): ?>
                <div class="tool-admin-item <?= $ann['is_active'] ? '' : 'inactive' ?>">
                    <div style="flex:1;">
                        <div class="tool-admin-name">
                            <span class="badge badge-<?= $ann['type'] ?>"><?= strtoupper($ann['type']) ?></span>
                            <?= htmlspecialchars($ann['message']) ?>
                            <?= !$ann['is_active'] ? '<span class="badge badge-off">OFF</span>' : '' ?>
                        </div>
                        <div class="tool-admin-meta">
                            <span><i class="fas fa-clock"></i> <?= $ann['created_at'] ?></span>
                        </div>
                    </div>
                    <div class="tool-admin-actions">
                        <form method="POST" style="display:inline">
                            <input type="hidden" name="action" value="toggle">
                            <input type="hidden" name="id" value="<?= $ann['id'] ?>">
                            <button type="submit" class="btn-icon <?= $ann['is_active'] ? 'btn-warning' : 'btn-success' ?>"
                                    title="Toggle">
                                <i class="fas fa-<?= $ann['is_active'] ? 'eye-slash' : 'eye' ?>"></i>
                            </button>
                        </form>
                        <form method="POST" style="display:inline"
                              onsubmit="return confirm('Delete this announcement?')">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="id" value="<?= $ann['id'] ?>">
                            <button type="submit" class="btn-icon btn-danger" title="Delete">
                                <i class="fas fa-trash"></i>
                            </button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>
<script src="../assets/js/admin.js"></script>
</body>
</html>
