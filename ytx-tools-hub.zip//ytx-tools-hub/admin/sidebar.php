<?php
// Developed by https://t.me/Infinity_Codex | owner: t.me/zerox6t9

require_once '../includes/config.php';
if (!isset($_SESSION[ADMIN_SESSION_KEY]) || !$_SESSION[ADMIN_SESSION_KEY]) {
    header('Location: login.php'); exit;
}

$db = getDB();
$primary_color = getSetting('primary_color', '#007AFF');
$msg = $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $items = [];
    $labels  = $_POST['label'] ?? [];
    $urls    = $_POST['url'] ?? [];
    $icons   = $_POST['icon'] ?? [];
    $targets = $_POST['target'] ?? [];
    foreach ($labels as $i => $label) {
        if (trim($label) && isset($urls[$i]) && trim($urls[$i])) {
            $items[] = [
                'label'  => trim($label),
                'url'    => trim($urls[$i]),
                'icon'   => trim($icons[$i] ?? 'fas fa-link'),
                'target' => ($targets[$i] ?? '') === '_blank' ? '_blank' : '_self',
            ];
        }
    }
    setSetting('sidebar_items', json_encode($items));
    $msg = '✅ Sidebar menu saved!';
}

$sidebar_items = json_decode(getSetting('sidebar_items', '[]'), true) ?: [];

// Default icons for picker
$icon_suggestions = [
    'fab fa-telegram-plane','fas fa-user-shield','fas fa-magic','fas fa-users-cog',
    'fas fa-link','fas fa-star','fas fa-home','fas fa-envelope','fas fa-globe',
    'fas fa-bell','fas fa-info-circle','fas fa-heart','fas fa-fire','fas fa-bolt',
    'fas fa-crown','fas fa-gift','fas fa-shield-alt','fas fa-code',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sidebar Menu - Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        :root { --primary: <?= htmlspecialchars($primary_color) ?>; }
        .sidebar-items-list { display:flex; flex-direction:column; gap:12px; }
        .sidebar-item-row { display:grid; grid-template-columns: 1fr 2fr 1.5fr 80px 40px; gap:10px; align-items:center;
            background: var(--admin-card); border:1px solid var(--admin-border); border-radius:10px; padding:12px 14px; }
        .sidebar-item-row label { font-size:11px; color:#888; margin-bottom:3px; }
        .sidebar-item-row .form-control { margin-bottom:0; }
        .row-drag { cursor: grab; color:#bbb; font-size:18px; }
        @media (max-width: 600px) {
            .sidebar-item-row { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
<?php include 'partials/sidebar.php'; ?>
<div class="admin-content">
    <?php include 'partials/topbar.php'; ?>
    <div class="admin-body">
        <div class="page-header">
            <h1><i class="fas fa-bars"></i> Sidebar Menu Editor</h1>
            <p>Add, edit, or remove sidebar menu items. Changes are saved instantly.</p>
        </div>

        <?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

        <div class="card">
            <div class="card-header"><i class="fas fa-list"></i> Menu Items</div>
            <div class="card-body">
                <form method="POST">
                    <div class="sidebar-items-list" id="sidebar-list">
                    <?php
                    $rows = $sidebar_items ?: [['label'=>'','url'=>'','icon'=>'fas fa-link','target'=>'_blank']];
                    foreach ($rows as $item):
                    ?>
                    <div class="sidebar-item-row">
                        <div>
                            <label>Label</label>
                            <input type="text" name="label[]" class="form-control"
                                   value="<?= htmlspecialchars($item['label'] ?? '') ?>"
                                   placeholder="e.g. Join Channel">
                        </div>
                        <div>
                            <label>URL</label>
                            <input type="text" name="url[]" class="form-control"
                                   value="<?= htmlspecialchars($item['url'] ?? '') ?>"
                                   placeholder="https://t.me/...">
                        </div>
                        <div>
                            <label>Icon Class <a href="https://fontawesome.com/icons" target="_blank" style="font-size:10px; color:var(--primary)">Browse Icons</a></label>
                            <input type="text" name="icon[]" class="form-control"
                                   value="<?= htmlspecialchars($item['icon'] ?? 'fas fa-link') ?>"
                                   placeholder="fas fa-link">
                        </div>
                        <div>
                            <label>Target</label>
                            <select name="target[]" class="form-control">
                                <option value="_blank" <?= ($item['target'] ?? '') === '_blank' ? 'selected' : '' ?>>New Tab</option>
                                <option value="_self"  <?= ($item['target'] ?? '') === '_self'  ? 'selected' : '' ?>>Same Tab</option>
                            </select>
                        </div>
                        <div style="text-align:center; padding-top:22px;">
                            <button type="button" class="btn-icon btn-danger" onclick="removeRow(this)" title="Remove">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    </div>

                    <div style="margin-top: 14px; display:flex; gap:10px; flex-wrap:wrap;">
                        <button type="button" class="btn btn-secondary" onclick="addRow()">
                            <i class="fas fa-plus"></i> Add Menu Item
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Save Menu
                        </button>
                    </div>

                    <!-- Icon suggestions -->
                    <div style="margin-top:20px;">
                        <div style="font-size:12px; color:#888; margin-bottom:8px;">Common Icons (click to copy class):</div>
                        <div style="display:flex; flex-wrap:wrap; gap:8px;">
                        <?php foreach ($icon_suggestions as $ico): ?>
                        <span class="icon-chip" onclick="copyIconClass(this, '<?= $ico ?>')">
                            <i class="<?= $ico ?>"></i> <?= $ico ?>
                        </span>
                        <?php endforeach; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
<script src="../assets/js/admin.js"></script>
<script>
function addRow() {
    const list = document.getElementById('sidebar-list');
    const tmpl = `<div class="sidebar-item-row">
        <div><label>Label</label><input type="text" name="label[]" class="form-control" placeholder="Menu Item"></div>
        <div><label>URL</label><input type="text" name="url[]" class="form-control" placeholder="https://..."></div>
        <div><label>Icon Class</label><input type="text" name="icon[]" class="form-control" value="fas fa-link" placeholder="fas fa-link"></div>
        <div><label>Target</label>
            <select name="target[]" class="form-control">
                <option value="_blank">New Tab</option>
                <option value="_self">Same Tab</option>
            </select>
        </div>
        <div style="text-align:center; padding-top:22px;">
            <button type="button" class="btn-icon btn-danger" onclick="removeRow(this)"><i class="fas fa-times"></i></button>
        </div>
    </div>`;
    list.insertAdjacentHTML('beforeend', tmpl);
}
function removeRow(btn) {
    btn.closest('.sidebar-item-row').remove();
}
function copyIconClass(el, cls) {
    const inputs = document.querySelectorAll('input[name="icon[]"]');
    if (inputs.length > 0) {
        inputs[inputs.length-1].value = cls;
        inputs[inputs.length-1].focus();
    }
    el.style.background = 'var(--primary)';
    el.style.color = '#fff';
    setTimeout(() => { el.style.background=''; el.style.color=''; }, 700);
}
</script>
</body>
</html>
