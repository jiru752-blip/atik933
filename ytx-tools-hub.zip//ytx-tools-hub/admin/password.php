<?php
// Developed by https://t.me/Infinity_Codex | owner: t.me/zerox6t9

require_once '../includes/config.php';
if (!isset($_SESSION[ADMIN_SESSION_KEY]) || !$_SESSION[ADMIN_SESSION_KEY]) {
    header('Location: login.php'); exit;
}

$db = getDB();
$primary_color = getSetting('primary_color', '#007AFF');
$msg = $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $current  = $_POST['current_password'] ?? '';
    $new      = $_POST['new_password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';
    $username = $_SESSION['admin_username'] ?? 'admin';

    if (!$current || !$new || !$confirm) {
        $err = 'All fields are required.';
    } elseif (strlen($new) < 6) {
        $err = 'New password must be at least 6 characters.';
    } elseif ($new !== $confirm) {
        $err = 'New passwords do not match.';
    } else {
        $u = $db->real_escape_string($username);
        $res = $db->query("SELECT password FROM admin_users WHERE username='$u' LIMIT 1");
        if ($res && $row = $res->fetch_assoc()) {
            if (password_verify($current, $row['password'])) {
                $hashed = password_hash($new, PASSWORD_DEFAULT);
                $h = $db->real_escape_string($hashed);
                $db->query("UPDATE admin_users SET password='$h' WHERE username='$u'");
                $msg = '✅ Password changed successfully!';
            } else {
                $err = 'Current password is incorrect.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>:root { --primary: <?= htmlspecialchars($primary_color) ?>; }</style>
</head>
<body>
<?php include 'partials/sidebar.php'; ?>
<div class="admin-content">
    <?php include 'partials/topbar.php'; ?>
    <div class="admin-body">
        <div class="page-header">
            <h1><i class="fas fa-key"></i> Change Password</h1>
        </div>

        <?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
        <?php if ($err): ?><div class="alert alert-danger"><?= htmlspecialchars($err) ?></div><?php endif; ?>

        <div class="card" style="max-width:480px;">
            <div class="card-header"><i class="fas fa-lock"></i> Update Admin Password</div>
            <div class="card-body">
                <form method="POST">
                    <div class="form-group">
                        <label>Current Password</label>
                        <input type="password" name="current_password" class="form-control" required placeholder="Current password">
                    </div>
                    <div class="form-group">
                        <label>New Password</label>
                        <input type="password" name="new_password" class="form-control" required placeholder="Min. 6 characters">
                    </div>
                    <div class="form-group">
                        <label>Confirm New Password</label>
                        <input type="password" name="confirm_password" class="form-control" required placeholder="Repeat new password">
                    </div>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Password
                    </button>
                </form>
            </div>
        </div>

    </div>
</div>
<script src="../assets/js/admin.js"></script>
</body>
</html>
