<?php
// Developed by https://t.me/Infinity_Codex | owner: t.me/zerox6t9

require_once '../includes/config.php';
session_destroy();
header('Location: login.php');
exit;
