<?php
// Developed by https://t.me/Infinity_Codex | owner: t.me/zerox6t9

$admin_user = $_SESSION['admin_username'] ?? 'Admin';
$page_title = $page_title ?? 'Dashboard';
?>
<div class="admin-topbar">
    <button class="sidebar-toggle" onclick="toggleSidebarAdmin()">
        <i class="fas fa-bars"></i>
    </button>
    <div class="topbar-right">
        <span class="admin-user"><i class="fas fa-user-circle"></i> <?= htmlspecialchars($admin_user) ?></span>
        <a href="logout.php" class="topbar-logout" title="Logout"><i class="fas fa-sign-out-alt"></i></a>
    </div>
</div>
