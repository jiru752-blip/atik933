<?php
// Developed by https://t.me/Infinity_Codex | owner: t.me/zerox6t9

$current_page = basename($_SERVER['PHP_SELF']);
$site_name = getSetting('site_name', 'YTX Tools Hub');
$site_logo = getSetting('site_logo', 'assets/img/ytx-logo.png');
$site_logo = $site_logo && !preg_match('/^(https?:|\\/)/i', $site_logo) ? '../' . ltrim($site_logo, '/') : $site_logo;
?>
<div class="admin-sidebar" id="admin-sidebar">
    <div class="admin-sidebar-head">
        <?php if ($site_logo): ?>
        <img src="<?= htmlspecialchars($site_logo) ?>" alt="Logo" class="admin-logo">
        <?php endif; ?>
        <div class="admin-brand"><?= htmlspecialchars($site_name) ?></div>
        <div class="admin-brand-sub">Admin Panel</div>
    </div>

    <nav class="admin-nav">
        <div class="nav-label">Main</div>
        <a href="index.php" class="nav-item <?= $current_page === 'index.php' ? 'active' : '' ?>">
            <i class="fas fa-tachometer-alt"></i> Dashboard
        </a>
        <a href="tools.php" class="nav-item <?= $current_page === 'tools.php' ? 'active' : '' ?>">
            <i class="fas fa-tools"></i> Manage Tools
        </a>
        <a href="announcements.php" class="nav-item <?= $current_page === 'announcements.php' ? 'active' : '' ?>">
            <i class="fas fa-bullhorn"></i> Announcements
        </a>
        <a href="banners.php" class="nav-item <?= $current_page === 'banners.php' ? 'active' : '' ?>">
            <i class="fas fa-images"></i> Sliding Banners
        </a>
        <a href="sidebar.php" class="nav-item <?= $current_page === 'sidebar.php' ? 'active' : '' ?>">
            <i class="fas fa-bars"></i> Sidebar Menu
        </a>

        <div class="nav-label">Configuration</div>
        <a href="settings.php" class="nav-item <?= $current_page === 'settings.php' ? 'active' : '' ?>">
            <i class="fas fa-cog"></i> Site Settings
        </a>
        <a href="appearance.php" class="nav-item <?= $current_page === 'appearance.php' ? 'active' : '' ?>">
            <i class="fas fa-paint-brush"></i> Appearance
        </a>
        <a href="password.php" class="nav-item <?= $current_page === 'password.php' ? 'active' : '' ?>">
            <i class="fas fa-key"></i> Change Password
        </a>

        <div class="nav-label">Site</div>
        <a href="../index.php" target="_blank" class="nav-item">
            <i class="fas fa-external-link-alt"></i> View Site
        </a>
        <a href="logout.php" class="nav-item danger">
            <i class="fas fa-sign-out-alt"></i> Logout
        </a>
    </nav>
</div>
<div class="sidebar-overlay-admin" id="sidebar-overlay-admin" onclick="closeSidebarAdmin()"></div>
