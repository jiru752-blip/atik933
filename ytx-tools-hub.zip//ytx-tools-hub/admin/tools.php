<?php
require_once '../includes/config.php';
if (!isset($_SESSION[ADMIN_SESSION_KEY]) || !$_SESSION[ADMIN_SESSION_KEY]) { header('Location: login.php'); exit; }
$db = getDB();
$primary_color = getSetting('primary_color', '#007AFF');
$msg = $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add' || $action === 'edit') {
        $name = trim($_POST['name'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $url = trim($_POST['url'] ?? '');
        $icon = trim($_POST['existing_icon'] ?? '');
        $cat = trim($_POST['category'] ?? 'General') ?: 'General';
        $active = isset($_POST['is_active']) ? 1 : 0;
        $order = intval($_POST['sort_order'] ?? 0);

        if (!$name || !$url) $err = 'Tool name and internal page path are required.';
        elseif (preg_match('/^(https?:)?\\/\\//i', $url) || strpos($url, '..') !== false) $err = 'Tool page must be an internal path such as tools/json-formatter.php.';
        else {
            $uploaded = saveUploadedImage('icon_file', 'tool-icon', $err);
            if ($uploaded) $icon = $uploaded;
            if (!$err) {
                $n=$db->real_escape_string($name); $d=$db->real_escape_string($desc); $u=$db->real_escape_string(ltrim($url, '/')); $ic=$db->real_escape_string($icon); $c=$db->real_escape_string($cat);
                if ($action === 'add') {
                    $db->query("INSERT INTO tools (name, description, url, icon, category, is_active, sort_order) VALUES ('$n','$d','$u','$ic','$c',$active,$order)");
                    $msg = 'Tool added successfully.';
                } else {
                    $id = intval($_POST['id']);
                    $db->query("UPDATE tools SET name='$n', description='$d', url='$u', icon='$ic', category='$c', is_active=$active, sort_order=$order WHERE id=$id");
                    $msg = 'Tool updated successfully.';
                }
            }
        }
    } elseif ($action === 'delete') {
        $db->query('DELETE FROM tools WHERE id=' . intval($_POST['id'] ?? 0));
        $msg = 'Tool deleted.';
    } elseif ($action === 'toggle') {
        $db->query('UPDATE tools SET is_active = IF(is_active=1, 0, 1) WHERE id=' . intval($_POST['id'] ?? 0));
        $msg = 'Tool status updated.';
    }
}

$edit_tool = null;
if (isset($_GET['edit'])) { $res = $db->query('SELECT * FROM tools WHERE id=' . intval($_GET['edit']) . ' LIMIT 1'); if ($res) $edit_tool = $res->fetch_assoc(); }
$tools = [];
$res = $db->query('SELECT * FROM tools ORDER BY sort_order ASC, id ASC');
if ($res) while ($row = $res->fetch_assoc()) $tools[] = $row;
?>
<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Manage Tools - YTX Admin</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"><link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet"><link rel="stylesheet" href="../assets/css/admin.css"><style>:root{--primary:<?= htmlspecialchars($primary_color) ?>}.upload-note{display:block;color:#718096;font-size:12px;margin-top:6px}.icon-preview-wrap img{width:58px;height:58px;object-fit:cover;border-radius:12px;margin-top:10px}</style></head>
<body><?php include 'partials/sidebar.php'; ?><div class="admin-content"><?php include 'partials/topbar.php'; ?><div class="admin-body">
<div class="page-header"><h1><i class="fas fa-tools"></i> Manage Tools</h1><p>Every tool opens inside the YTX tools viewer—no external redirect.</p></div>
<?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?><?php if ($err): ?><div class="alert alert-danger"><?= htmlspecialchars($err) ?></div><?php endif; ?>
<div class="card"><div class="card-header"><i class="fas fa-<?= $edit_tool ? 'edit' : 'plus-circle' ?>"></i> <?= $edit_tool ? 'Edit Tool' : 'Add New Tool' ?></div><div class="card-body">
<form method="POST" enctype="multipart/form-data"><input type="hidden" name="action" value="<?= $edit_tool ? 'edit' : 'add' ?>"><?php if($edit_tool): ?><input type="hidden" name="id" value="<?= $edit_tool['id'] ?>"><?php endif; ?><input type="hidden" name="existing_icon" value="<?= htmlspecialchars($edit_tool['icon'] ?? '') ?>">
<div class="form-row"><div class="form-group"><label>Tool Name *</label><input type="text" name="name" class="form-control" required value="<?= htmlspecialchars($edit_tool['name'] ?? '') ?>" placeholder="e.g. JSON Formatter"></div><div class="form-group"><label>Category</label><input type="text" name="category" class="form-control" value="<?= htmlspecialchars($edit_tool['category'] ?? 'Utility') ?>" placeholder="e.g. Developer"></div></div>
<div class="form-group"><label>Tool Page Path *</label><input type="text" name="url" class="form-control" required value="<?= htmlspecialchars($edit_tool['url'] ?? '') ?>" placeholder="tools/json-formatter.php"><small class="upload-note">Use an internal page path only. External website links are blocked so users stay inside YTX.</small></div>
<div class="form-group"><label>Tool Icon</label><input type="file" name="icon_file" class="form-control" accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml,image/x-icon"><small class="upload-note">Choose an image file directly. Maximum 5 MB. Leave empty to keep the current icon.</small><div class="icon-preview-wrap"><?php if(!empty($edit_tool['icon'])): ?><img src="../<?= htmlspecialchars($edit_tool['icon']) ?>" alt="Icon preview"><?php endif; ?></div></div>
<div class="form-group"><label>Description</label><input type="text" name="description" class="form-control" value="<?= htmlspecialchars($edit_tool['description'] ?? '') ?>" placeholder="Short description..."></div>
<div class="form-row"><div class="form-group"><label>Sort Order</label><input type="number" name="sort_order" class="form-control" value="<?= $edit_tool['sort_order'] ?? 0 ?>"></div><div class="form-group" style="padding-top:28px"><label class="checkbox-label"><input type="checkbox" name="is_active" <?= (!$edit_tool || $edit_tool['is_active']) ? 'checked' : '' ?>> Active (visible on site)</label></div></div>
<div class="form-actions"><button class="btn btn-primary" type="submit"><i class="fas fa-save"></i> <?= $edit_tool ? 'Update Tool' : 'Add Tool' ?></button><?php if($edit_tool): ?><a href="tools.php" class="btn btn-secondary">Cancel</a><?php endif; ?></div></form></div></div>
<div class="card"><div class="card-header"><i class="fas fa-list"></i> All Tools (<?= count($tools) ?>)</div><div class="card-body" style="padding:0"><?php if(!$tools): ?><div style="padding:30px;text-align:center;color:#999">No tools yet.</div><?php else: ?><div class="tools-admin-list"><?php foreach($tools as $tool): ?><div class="tool-admin-item <?= $tool['is_active']?'':'inactive' ?>"><div class="tool-admin-icon"><img src="../<?= htmlspecialchars($tool['icon'] ?: 'assets/img/ytx-logo.png') ?>" alt=""></div><div class="tool-admin-info"><div class="tool-admin-name"><?= htmlspecialchars($tool['name']) ?> <span class="badge badge-<?= $tool['is_active']?'on':'off' ?>"><?= $tool['is_active']?'ON':'OFF' ?></span></div><div class="tool-admin-meta"><span><i class="fas fa-tag"></i> <?= htmlspecialchars($tool['category']) ?></span><span><i class="fas fa-file-code"></i> <?= htmlspecialchars($tool['url']) ?></span><span><i class="fas fa-sort"></i> Order: <?= $tool['sort_order'] ?></span></div></div><div class="tool-admin-actions"><form method="POST"><input type="hidden" name="action" value="toggle"><input type="hidden" name="id" value="<?= $tool['id'] ?>"><button class="btn-icon <?= $tool['is_active']?'btn-warning':'btn-success' ?>" title="Toggle"><i class="fas fa-<?= $tool['is_active']?'eye-slash':'eye' ?>"></i></button></form><a href="tools.php?edit=<?= $tool['id'] ?>" class="btn-icon btn-info" title="Edit"><i class="fas fa-edit"></i></a><form method="POST" onsubmit="return confirm('Delete this tool?')"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?= $tool['id'] ?>"><button class="btn-icon btn-danger" title="Delete"><i class="fas fa-trash"></i></button></form></div></div><?php endforeach; ?></div><?php endif; ?></div></div>
</div></div><script src="../assets/js/admin.js"></script></body></html>
