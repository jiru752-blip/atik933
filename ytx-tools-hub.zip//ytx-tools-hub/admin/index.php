<?php
// Developed by https://t.me/Infinity_Codex | owner: t.me/zerox6t9

require_once '../includes/config.php';

// Check login
if (!isset($_SESSION[ADMIN_SESSION_KEY]) || $_SESSION[ADMIN_SESSION_KEY] !== true) {
    header('Location: login.php');
    exit;
}

// Quick stats
$db = getDB();
$total_tools   = $db->query("SELECT COUNT(*) as c FROM tools")->fetch_assoc()['c'] ?? 0;
$active_tools  = $db->query("SELECT COUNT(*) as c FROM tools WHERE is_active=1")->fetch_assoc()['c'] ?? 0;
$total_ann     = $db->query("SELECT COUNT(*) as c FROM announcements WHERE is_active=1")->fetch_assoc()['c'] ?? 0;
$total_banners = $db->query("SELECT COUNT(*) as c FROM banners")->fetch_assoc()['c'] ?? 0;
$site_active   = getSetting('site_active', '1');
$site_name     = getSetting('site_name', 'YTX Tools Hub');
$primary_color = getSetting('primary_color', '#007AFF');
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - <?= htmlspecialchars($site_name) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>:root { --primary: <?= htmlspecialchars($primary_color) ?>; }</style>
</head>
<body>
<?php include 'partials/sidebar.php'; ?>

<div class="admin-content">
    <?php include 'partials/topbar.php'; ?>

    <div class="admin-body">
        <div class="page-header">
            <h1><i class="fas fa-tachometer-alt"></i> Dashboard</h1>
            <p>YTX Tools Hub Admin Overview</p>
        </div>

        <!-- Site Status Toggle -->
        <div class="status-banner <?= $site_active === '1' ? 'online' : 'offline' ?>">
            <div>
                <span class="status-dot"></span>
                <strong>Site Status:</strong>
                <?= $site_active === '1' ? '🟢 ONLINE — সাইট চালু আছে' : '🔴 OFFLINE — Maintenance Mode' ?>
            </div>
            <form method="POST" action="ajax/settings.php" style="display:inline">
                <input type="hidden" name="action" value="toggle_site">
                <input type="hidden" name="site_active" value="<?= $site_active === '1' ? '0' : '1' ?>">
                <button type="submit" class="btn <?= $site_active === '1' ? 'btn-danger' : 'btn-success' ?>">
                    <i class="fas fa-power-off"></i>
                    <?= $site_active === '1' ? 'Turn OFF' : 'Turn ON' ?>
                </button>
            </form>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon blue"><i class="fas fa-tools"></i></div>
                <div class="stat-info">
                    <div class="stat-num"><?= $total_tools ?></div>
                    <div class="stat-label">Total Tools</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon green"><i class="fas fa-check-circle"></i></div>
                <div class="stat-info">
                    <div class="stat-num"><?= $active_tools ?></div>
                    <div class="stat-label">Active Tools</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon orange"><i class="fas fa-bullhorn"></i></div>
                <div class="stat-info">
                    <div class="stat-num"><?= $total_ann ?></div>
                    <div class="stat-label">Announcements</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon purple"><i class="fas fa-images"></i></div>
                <div class="stat-info">
                    <div class="stat-num"><?= $total_banners ?></div>
                    <div class="stat-label">Sliding Banners</div>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon purple"><i class="fas fa-globe"></i></div>
                <div class="stat-info">
                    <div class="stat-num"><?= $site_active === '1' ? 'ON' : 'OFF' ?></div>
                    <div class="stat-label">Site Mode</div>
                </div>
            </div>
        </div>

        <!-- Quick Links -->
        <div class="quick-links">
            <h3>Quick Actions</h3>
            <div class="quick-grid">
                <a href="tools.php" class="quick-card">
                    <i class="fas fa-plus-circle"></i><span>Add Tool</span>
                </a>
                <a href="settings.php" class="quick-card">
                    <i class="fas fa-cog"></i><span>Settings</span>
                </a>
                <a href="announcements.php" class="quick-card">
                    <i class="fas fa-bullhorn"></i><span>Announcement</span>
                </a>
                <a href="banners.php" class="quick-card">
                    <i class="fas fa-images"></i><span>Manage Banners</span>
                </a>
                <a href="sidebar.php" class="quick-card">
                    <i class="fas fa-bars"></i><span>Sidebar Menu</span>
                </a>
                <a href="../index.php" target="_blank" class="quick-card">
                    <i class="fas fa-eye"></i><span>View Site</span>
                </a>
                <a href="password.php" class="quick-card">
                    <i class="fas fa-key"></i><span>Change Password</span>
                </a>
            </div>
        </div>

    </div>
</div>

<script src="../assets/js/admin.js"></script>
</body>
</html>
