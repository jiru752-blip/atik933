<?php
// Developed by https://t.me/Infinity_Codex | owner: t.me/zerox6t9

require_once '../includes/config.php';

// Already logged in
if (isset($_SESSION[ADMIN_SESSION_KEY]) && $_SESSION[ADMIN_SESSION_KEY] === true) {
    header('Location: index.php'); exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if ($username && $password) {
        $db = getDB();
        $u = $db->real_escape_string($username);
        $res = $db->query("SELECT * FROM admin_users WHERE username = '$u' LIMIT 1");
        if ($res && $row = $res->fetch_assoc()) {
            if (password_verify($password, $row['password'])) {
                $_SESSION[ADMIN_SESSION_KEY] = true;
                $_SESSION['admin_username'] = $row['username'];
                header('Location: index.php'); exit;
            }
        }
        $error = 'Invalid username or password.';
    } else {
        $error = 'Please fill in all fields.';
    }
}

$site_name     = getSetting('site_name', 'YTX Tools Hub');
$site_logo     = getSetting('site_logo', 'assets/img/ytx-logo.png');
$site_logo     = $site_logo && !preg_match('/^(https?:|\\/)/i', $site_logo) ? '../' . ltrim($site_logo, '/') : $site_logo;
$primary_color = getSetting('primary_color', '#007AFF');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - <?= htmlspecialchars($site_name) ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <style>
        :root { --primary: <?= htmlspecialchars($primary_color) ?>; }
        body { display:flex; align-items:center; justify-content:center; min-height:100vh; background: var(--admin-bg); }
    </style>
</head>
<body>
<div class="login-wrap">
    <div class="login-card">
        <?php if ($site_logo): ?>
        <img src="<?= htmlspecialchars($site_logo) ?>" alt="Logo" class="login-logo">
        <?php endif; ?>
        <h2 class="login-title">Admin Panel</h2>
        <p class="login-sub"><?= htmlspecialchars($site_name) ?></p>

        <?php if ($error): ?>
        <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label><i class="fas fa-user"></i> Username</label>
                <input type="text" name="username" class="form-control"
                       value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                       placeholder="Enter username" required autofocus>
            </div>
            <div class="form-group">
                <label><i class="fas fa-lock"></i> Password</label>
                <div class="pass-wrap">
                    <input type="password" name="password" id="pass-field" class="form-control"
                           placeholder="Enter password" required>
                    <span class="pass-toggle" onclick="togglePass()"><i class="fas fa-eye" id="pass-icon"></i></span>
                </div>
            </div>
            <button type="submit" class="btn btn-primary btn-block">
                <i class="fas fa-sign-in-alt"></i> Login
            </button>
        </form>
    </div>
</div>
<script>
function togglePass() {
    const f = document.getElementById('pass-field');
    const i = document.getElementById('pass-icon');
    f.type = f.type === 'password' ? 'text' : 'password';
    i.className = f.type === 'password' ? 'fas fa-eye' : 'fas fa-eye-slash';
}
</script>
</body>
</html>
