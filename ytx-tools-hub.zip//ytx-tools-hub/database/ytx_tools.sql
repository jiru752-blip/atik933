/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: ytx_tools
-- ------------------------------------------------------
-- Server version	10.11.14-MariaDB-0ubuntu0.24.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_users`
--

DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_users`
--

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES
(1,'admin','$2y$10$aNEwm0gNYFrMybDzt.JineLwKfO1dPlRXZ852g1rjWOrZ9sjsJbfS','2026-10-23 12:54:00');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message` text NOT NULL,
  `type` enum('info','warning','success','error') DEFAULT 'info',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES
(1,'👋 YTX Tools Hub-এ স্বাগতম! নতুন টুলস যোগ হচ্ছে প্রতিদিন।','info',1,'2026-10-23 12:54:00');
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `banners`
--

DROP TABLE IF EXISTS `banners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `banners` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(500) DEFAULT '',
  `image_url` text DEFAULT NULL,
  `link_url` text DEFAULT NULL,
  `button_text` varchar(100) DEFAULT 'Explore now',
  `sort_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `banners`
--

LOCK TABLES `banners` WRITE;
/*!40000 ALTER TABLE `banners` DISABLE KEYS */;
INSERT INTO `banners` VALUES
(1,'Your next useful tool is closer than you think.','A focused collection for faster work and better flow.','','#toolkit','Explore toolkit',0,1,'2026-10-23 13:01:16','2026-10-23 13:01:16');
/*!40000 ALTER TABLE `banners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `value` text DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
(1,'site_name','YTX Tools Hub','2026-10-23 12:57:30'),
(2,'site_tagline','🧑‍💻','2026-10-23 12:54:00'),
(3,'site_logo','assets/img/ytx-logo.png','2026-10-23 12:58:50'),
(4,'site_banner','','2026-10-23 12:57:30'),
(5,'primary_color','#007AFF','2026-10-23 12:54:00'),
(6,'channel_url','','2026-10-23 12:57:30'),
(7,'group_url','','2026-10-23 12:57:30'),
(8,'developer_url','','2026-10-23 12:57:30'),
(9,'developer_name','','2026-10-23 12:57:30'),
(10,'channel_name','Channel','2026-10-23 12:54:00'),
(11,'group_name','Group','2026-10-23 12:54:00'),
(12,'site_active','1','2026-10-23 12:54:00'),
(13,'maintenance_msg','সাইটটি এখন মেইনটেন্যান্সে আছে। শীঘ্রই ফিরে আসছি!','2026-10-23 12:54:00'),
(14,'footer_text','YTX Tools Hub','2026-10-23 12:57:30'),
(15,'search_placeholder','Search premium tools...','2026-10-23 12:54:00'),
(16,'tools_title','YTX Tools Hub','2026-10-23 12:57:30'),
(17,'sidebar_items','[]','2026-10-23 12:57:30'),
(18,'particles_enabled','1','2026-10-23 12:54:00'),
(19,'glow_enabled','1','2026-10-23 12:54:00'),
(20,'animations_enabled','1','2026-10-23 12:54:00'),
(21,'site_favicon','assets/img/ytx-logo.png','2026-10-23 13:07:36');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tools`
--

DROP TABLE IF EXISTS `tools`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tools` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `url` text NOT NULL,
  `icon` text DEFAULT NULL,
  `category` varchar(100) DEFAULT 'General',
  `is_active` tinyint(1) DEFAULT 1,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tools`
--

LOCK TABLES `tools` WRITE;
/*!40000 ALTER TABLE `tools` DISABLE KEYS */;
INSERT INTO `tools` VALUES
(1,'JSON Formatter','Format, validate and minify JSON locally','tools/index.php?tool=json','assets/img/tools/json.svg','Developer',1,0,'2026-10-23 12:54:00','2026-10-23 12:54:00'),
(2,'Base64 Encoder','Encode and decode text locally','tools/index.php?tool=base64','assets/img/tools/lock.svg','Security',1,1,'2026-10-23 12:54:00','2026-10-23 12:54:00'),
(3,'URL Encoder','Encode or decode URL components','tools/index.php?tool=url','assets/img/tools/link.svg','Developer',1,2,'2026-10-23 12:54:00','2026-10-23 12:54:00'),
(4,'UUID Generator','Generate UUID v4 identifiers','tools/index.php?tool=uuid','assets/img/tools/fingerprint.svg','Developer',1,3,'2026-10-23 12:54:00','2026-10-23 12:54:00'),
(5,'Color Converter','Convert HEX, RGB and HSL values','tools/index.php?tool=color','assets/img/tools/palette.svg','Design',1,4,'2026-10-23 12:54:00','2026-10-23 12:54:00'),
(6,'Password Generator','Create strong passwords locally','tools/index.php?tool=password','assets/img/tools/key.svg','Security',1,5,'2026-10-23 12:54:00','2026-10-23 12:54:00');
/*!40000 ALTER TABLE `tools` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-23 13:08:58
