/* Developed by https://t.me/Infinity_Codex | owner: t.me/zerox6t9 */
/* ===== YTX TOOLS HUB - Main JavaScript ===== */

/* ===== Particles Animation ===== */
(function initParticles() {
    const canvas = document.getElementById('bg-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let W, H, particles = [], animId;

    function resize() {
        W = canvas.width = window.innerWidth;
        H = canvas.height = window.innerHeight;
    }
    resize();
    window.addEventListener('resize', resize);

    const primaryColor = getComputedStyle(document.documentElement)
        .getPropertyValue('--primary-rgb').trim() || '0, 122, 255';

    for (let i = 0; i < 18; i++) {
        particles.push({
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            vx: (Math.random() - 0.5) * 0.25,
            vy: (Math.random() - 0.5) * 0.25,
            r: Math.random() * 1.8 + 0.5,
            alpha: Math.random() * 0.12 + 0.03,
        });
    }

    function draw() {
        ctx.clearRect(0, 0, W, H);
        particles.forEach(p => {
            p.x += p.vx; p.y += p.vy;
            if (p.x < 0) p.x = W; if (p.x > W) p.x = 0;
            if (p.y < 0) p.y = H; if (p.y > H) p.y = 0;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${primaryColor}, ${p.alpha})`;
            ctx.fill();
        });
        animId = requestAnimationFrame(draw);
    }
    draw();
})();

/* ===== Sidebar ===== */
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
    document.body.style.overflow = sidebar.classList.contains('active') ? 'hidden' : '';
}

/* ===== Announcement Close ===== */
function closeAnnouncement(btn) {
    const el = btn.closest('.announcement');
    el.style.transition = 'all 0.3s ease';
    el.style.opacity = '0';
    el.style.transform = 'translateY(-10px)';
    setTimeout(() => el.remove(), 300);
}

/* ===== Tool Viewer ===== */
function openTool(url, name, iconSrc) {
    const viewer = document.getElementById('tool-viewer');
    const frame = document.getElementById('viewer-frame');
    const title = document.getElementById('viewer-title');
    const icon = document.getElementById('viewer-icon');

    frame.src = url;
    title.textContent = name;
    if (iconSrc) { icon.src = iconSrc; icon.style.display = 'block'; }
    else { icon.style.display = 'none'; }

    viewer.classList.add('active');
    document.body.style.overflow = 'hidden';

    // Push state for back button
    history.pushState({ toolOpen: true }, '', '#tool-open');
}

function closeTool() {
    const viewer = document.getElementById('tool-viewer');
    const frame = document.getElementById('viewer-frame');
    viewer.classList.remove('active');
    document.body.style.overflow = '';
    setTimeout(() => { frame.src = ''; }, 300);
    if (history.state && history.state.toolOpen) history.back();
}

// Handle browser back button
window.addEventListener('popstate', function (e) {
    const viewer = document.getElementById('tool-viewer');
    if (viewer && viewer.classList.contains('active')) {
        viewer.classList.remove('active');
        document.getElementById('viewer-frame').src = '';
        document.body.style.overflow = '';
    }
});

/* ===== Search / Filter ===== */
function filterTools() {
    const q = document.getElementById('search-input').value.trim().toLowerCase();
    const cards = document.querySelectorAll('.tool-card[data-name]');
    let found = 0;

    cards.forEach(card => {
        const name = card.dataset.name.toLowerCase();
        const desc = (card.dataset.desc || '').toLowerCase();
        const cat = (card.dataset.cat || '').toLowerCase();
        const match = !q || name.includes(q) || desc.includes(q) || cat.includes(q);
        card.style.display = match ? '' : 'none';
        if (match) found++;
    });

    // Show "no results" if nothing found
    let noRes = document.getElementById('no-results');
    if (found === 0) {
        if (!noRes) {
            noRes = document.createElement('div');
            noRes.id = 'no-results';
            noRes.className = 'no-results';
            noRes.innerHTML = '<i class="fas fa-search"></i><p>কোনো টুল পাওয়া যায়নি।<br><small>Try a different keyword</small></p>';
            document.getElementById('tools-grid').appendChild(noRes);
        }
    } else {
        if (noRes) noRes.remove();
    }
}

/* ===== Card Stagger Animation ===== */
document.addEventListener('DOMContentLoaded', function () {
    const cards = document.querySelectorAll('.tool-card');
    cards.forEach((card, i) => {
        card.style.animationDelay = (i * 0.06) + 's';
    });
});

/* ===== Ripple Effect on Cards ===== */
document.addEventListener('click', function (e) {
    const card = e.target.closest('.tool-card');
    if (!card) return;
    const ripple = document.createElement('span');
    const rect = card.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    ripple.style.cssText = `
        position:absolute; border-radius:50%;
        width:${size}px; height:${size}px;
        left:${e.clientX - rect.left - size/2}px;
        top:${e.clientY - rect.top - size/2}px;
        background:rgba(0,122,255,0.15);
        transform:scale(0); animation:ripple 0.55s ease-out forwards;
        pointer-events:none;
    `;
    card.style.position = 'relative';
    card.style.overflow = 'hidden';
    card.appendChild(ripple);
    setTimeout(() => ripple.remove(), 600);
});

// Ripple keyframe
const style = document.createElement('style');
style.textContent = '@keyframes ripple { to { transform: scale(2.5); opacity: 0; } }';
document.head.appendChild(style);

/* ===== Sliding banners ===== */
let currentBanner=0;let bannerTimer;
function showBanner(index){const slides=document.querySelectorAll('.banner-slide'),dots=document.querySelectorAll('.banner-dot');if(!slides.length)return;currentBanner=(index+slides.length)%slides.length;slides.forEach((s,i)=>s.classList.toggle('active',i===currentBanner));dots.forEach((d,i)=>d.classList.toggle('active',i===currentBanner));}
function moveBanner(step){showBanner(currentBanner+step);restartBannerTimer();}
function restartBannerTimer(){clearInterval(bannerTimer);const count=document.querySelectorAll('.banner-slide').length;if(count>1)bannerTimer=setInterval(()=>showBanner(currentBanner+1),5000);}
document.addEventListener('DOMContentLoaded',()=>{restartBannerTimer();const slider=document.getElementById('banner-slider');if(slider){slider.addEventListener('mouseenter',()=>clearInterval(bannerTimer));slider.addEventListener('mouseleave',restartBannerTimer)}});
